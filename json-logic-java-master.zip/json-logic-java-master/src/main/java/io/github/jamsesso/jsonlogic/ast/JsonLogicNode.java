package io.github.jamsesso.jsonlogic.ast;

public interface JsonLogicNode {
  JsonLogicNodeType getType();
}
