package io.github.jamsesso.jsonlogic.ast;

public enum JsonLogicNodeType {
  PRIMITIVE,
  VARIABLE,
  ARRAY,
  OPERATION
}
