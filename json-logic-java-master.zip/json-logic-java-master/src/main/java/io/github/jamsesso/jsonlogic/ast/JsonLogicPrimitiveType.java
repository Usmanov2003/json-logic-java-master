package io.github.jamsesso.jsonlogic.ast;

public enum JsonLogicPrimitiveType {
  STRING,
  NUMBER,
  BOOLEAN,
  NULL
}
